package cg.com.su;

public class PrimeNumber {

}


package com.api.Restapi;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.api.Restapi.entity.User;

@RestController
public class UserController {

	@GetMapping("/users")
	public List<User> getAllUser(){
		List<User> userList = new ArrayList<>();
		User u1 = new User(11, "Gayatri", 22, "Female");
		User u2 = new User(12, "Sampath", 20, "Male");
		User u3 = new User(13, "Nivisha", 20, "Female");
		User u4 = new User(14, "Sana", 19 ,"female");
		
		userList.add(u1);
		userList.add(u2);
		userList.add(u3);
		userList.add(u4);
		
		return userList;
	}

}
